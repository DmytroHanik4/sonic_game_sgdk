#ifndef _RES_RES_GFX_H_
#define _RES_RES_GFX_H_

extern const Image bg_B;
extern const Image bg_A;

#endif // _RES_RES_GFX_H_
