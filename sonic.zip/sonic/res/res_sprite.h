#ifndef _RES_RES_SPRITE_H_
#define _RES_RES_SPRITE_H_

extern const SpriteDefinition sonic_sprite;

#endif // _RES_RES_SPRITE_H_
