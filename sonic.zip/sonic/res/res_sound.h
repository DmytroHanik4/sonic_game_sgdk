#ifndef _RES_RES_SOUND_H_
#define _RES_RES_SOUND_H_

extern const u8 ghz_mus[21760];

#endif // _RES_RES_SOUND_H_
