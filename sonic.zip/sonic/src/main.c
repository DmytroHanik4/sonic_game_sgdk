#include <genesis.h>
#include "res_gfx.h"
#include "res_sprite.h"
#include "res_sound.h"

int main()
{

	u16 ind = TILE_USER_INDEX;

	// куда смотрит Рапунцель. FALSE - вправо, TRUE - влево
	u8 hFlipSonic = FALSE;

	// что нажато на первом контроллере
	u16 joy1 = 0;

	// координата X спрайта Рапунцель
	s16 xSonic = 100;

	s16 ySonic = 160;

	// количество циклов которое не нажимали на кнопки контроллера
	// на самом деле только 'влево' и 'вправо', нажатие остальных кнопок ни на что не влияет
	// когда достигнет 128 рапунцель начнет чисать волосы
	u8 time = 0;

	XGM_startPlay(ghz_mus);

	PAL_setColor(0, RGB24_TO_VDPCOLOR(0x0000FF));

	PAL_setPalette(PAL2, bg_A.palette->data, DMA);
	VDP_drawImageEx(BG_A, &bg_A, TILE_ATTR_FULL(PAL2, FALSE, FALSE, FALSE, ind), 0, 0, FALSE, TRUE);
	ind += bg_A.tileset->numTile;
	PAL_setPalette(PAL1, bg_B.palette->data, DMA);
	VDP_drawImageEx(BG_B, &bg_B, TILE_ATTR_FULL(PAL1, FALSE, FALSE, FALSE, ind), 0, 0, FALSE, TRUE);
	VDP_setScrollingMode(HSCROLL_TILE, VSCROLL_PLANE);

	Sprite *sonicSprite;

	SPR_init();

	PAL_setPalette(PAL3, sonic_sprite.palette->data, DMA);

	sonicSprite = SPR_addSprite(&sonic_sprite, xSonic, ySonic, TILE_ATTR(
			PAL3 // палитра
			,0// приоритет спрайта (спрайт с меньшим числом, будет перекрывать спрайт с большим)
			,FALSE// перевернуть по вертикали
			,FALSE// перевернуть по горизонтали
	));




	VDP_setPlaneSize(64, 32, TRUE);

	s16 scroll_bgb_x = 0;

	s16 offset_mask[29];

	memset(offset_mask, 0, 29 * sizeof(u16));

	while(1)
    {
    	SPR_update();
    	joy1 = JOY_readJoypad(JOY_1);

    	SPR_setHFlip(sonicSprite, hFlipSonic);
    	SPR_setPosition(sonicSprite, xSonic, ySonic);

    	if (joy1 & BUTTON_RIGHT) {
			// нажата кнопка 'вправо'
			// сбрасываем количество циклов которое не нажимали кнопки в 0
			time = 0;
			// чтоб Рапунцель смотрела вправо
			hFlipSonic = FALSE;
			// меняем позицию Рапунцель вправо на 1 (ходьба)
			xSonic += 1;

			if (joy1 & BUTTON_B) {
				// нажата кнопка 'B' (и кнопка 'вправо')
				// меняем позицию Рапунцель вправо  еще на 2 (бег)
				xSonic += 2;
				// меняем анимацию спрайта Рапунцель на бег
				SPR_setAnim(sonicSprite, 3);
			} else {
				// кнопка 'B' НЕ нажата (только 'вправо' нажата)
				// меняем анимацию спрайта Рапунцель на ходьбу
				SPR_setAnim(sonicSprite, 2);
			}
		} else if (joy1 & BUTTON_LEFT) {
			// нажата кнопка 'влево'
			// сбрасываем количество циклов которое не нажимали кнопки в 0
			time = 0;
			// чтоб Рапунцель смотрела влево
			hFlipSonic = TRUE;
			// меняем позицию Рапунцель влево на 1 (ходьба)
			xSonic -= 1;

			if (joy1 & BUTTON_B) {
				// нажата кнопка 'B' (и кнопка 'влево')
				// меняем позицию Рапунцель влево еще на 2 (бег)
				xSonic -= 2;
				// меняем анимацию спрайта Рапунцель на бег
				SPR_setAnim(sonicSprite, 3);
			} else {
				// кнопка 'B' НЕ нажата (только 'влево' нажата)
				// меняем анимацию спрайта Рапунцель на ходьбу
				SPR_setAnim(sonicSprite, 2);
			}
		} else {
			// кнопки 'влево' и 'вправо' не нажаты
			// количество циклов которое не нажимали кнопки увиличиваем на еденицу
			time++;

			if (time < 128) {
				// устанавливаем анимацию когда Рапунцель просто стоит с вытянутой сковородой
				SPR_setAnim(sonicSprite, 0);
			} else {
				// time стало 128 или больше 128
				// устанавливаем спрайту Рапунцель анимацию при которой она чешет волосы
				SPR_setAnim(sonicSprite, 1);
			}
		}
    	VDP_setHorizontalScrollTile(BG_B, 0, offset_mask, 28, CPU);

    	offset_mask[0] += 1;
    	offset_mask[1] += 1;
    	offset_mask[2] += 2;
    	offset_mask[3] += 3;
    	offset_mask[4] += 3;
    	offset_mask[5] += 4;

    	for (int i = 7; i < 18; i++) {
    		offset_mask[i] -= 1;
    	}

    	for (int j = 18; j < 28; j++) {
    		offset_mask[j] -= (j - 15);
    	}
    	scroll_bgb_x -= 1;
        SYS_doVBlankProcess();
    }

    return 0;
}